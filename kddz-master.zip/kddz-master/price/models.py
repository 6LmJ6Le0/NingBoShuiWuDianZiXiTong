from django.db import models

# Create your models here.
class Goods(models.Model):
    pass